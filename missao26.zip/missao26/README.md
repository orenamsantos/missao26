# Método Africano - Site Limpo e Funcional

## Descrição
Site profissional e responsivo para o "Método Africano" com página de apresentação (pressel) e quiz interativo personalizado. O código foi completamente limpo, organizado e otimizado a partir do site original.

## Funcionalidades

### 🎯 Página de Apresentação (Pressel)
- Design moderno e profissional com fundo escuro
- Animações suaves e efeitos visuais sofisticados
- Título com gradiente e efeitos de texto
- Botão CTA com animações de hover e ripple
- Cards de estatísticas com efeitos interativos
- Totalmente responsivo para desktop e mobile

### 📋 Quiz Interativo
- 8 perguntas personalizadas sobre estilo de vida
- Barra de progresso animada
- Transições suaves entre perguntas
- Validação de respostas
- Navegação bidirecional (anterior/próxima)
- Efeitos visuais nas opções selecionadas

### 📊 Sistema de Resultado
- Cálculo automático de score baseado nas respostas
- Diagnóstico personalizado com 5 níveis diferentes
- Interface visual atrativa para mostrar resultados
- Opção de reiniciar o quiz

## Estrutura do Projeto

```
metodo-africano/
├── index.html          # Página principal
├── styles.css          # Estilos CSS organizados
├── script.js           # JavaScript funcional
└── README.md           # Documentação
```

## Tecnologias Utilizadas
- **HTML5** - Estrutura semântica
- **CSS3** - Estilos modernos com animações
- **JavaScript ES6** - Funcionalidades interativas
- **Google Fonts** - Tipografia Montserrat
- **Design Responsivo** - Mobile-first approach

## Como Usar

### 1. Servidor Local
```bash
# Navegue até o diretório
cd metodo-africano

# Inicie um servidor HTTP local
python3 -m http.server 8000

# Acesse no navegador
http://localhost:8000
```

### 2. Deploy em Produção
O site pode ser hospedado em qualquer servidor web estático:
- Netlify
- Vercel
- GitHub Pages
- Servidor Apache/Nginx

## Funcionalidades Testadas ✅

### Página de Apresentação
- ✅ Carregamento e animações iniciais
- ✅ Responsividade em diferentes tamanhos de tela
- ✅ Efeitos hover nos elementos interativos
- ✅ Botão CTA funcional

### Quiz
- ✅ Navegação entre todas as 8 perguntas
- ✅ Seleção e validação de opções
- ✅ Barra de progresso funcionando
- ✅ Botões anterior/próxima
- ✅ Transições suaves

### Sistema de Resultado
- ✅ Cálculo correto do score
- ✅ Exibição de diagnóstico personalizado
- ✅ Botão de reiniciar funcionando
- ✅ Retorno à página inicial

## Melhorias Implementadas

### Design e UX
- Interface completamente redesenhada
- Animações suaves e profissionais
- Efeitos visuais modernos (gradientes, sombras, ripple)
- Tipografia melhorada
- Cores consistentes com a marca

### Performance
- Código JavaScript otimizado
- CSS organizado e eficiente
- Carregamento rápido
- Animações performáticas

### Responsividade
- Layout adaptável para mobile
- Botões e textos otimizados para touch
- Navegação intuitiva em dispositivos pequenos

## Personalização

### Cores
As cores principais podem ser alteradas no arquivo `styles.css`:
- Vermelho principal: `#ED1C24`
- Fundo escuro: `#000`
- Texto claro: `#F2EAD3`

### Perguntas do Quiz
As perguntas podem ser modificadas no arquivo `script.js` na variável `quizData`.

### Textos
Todos os textos podem ser editados diretamente no `index.html`.

## Suporte
- ✅ Chrome/Chromium
- ✅ Firefox
- ✅ Safari
- ✅ Edge
- ✅ Mobile browsers

## Licença
Projeto desenvolvido para uso comercial do Método Africano.

---
**Desenvolvido com ❤️ - Código limpo, funcional e profissional**

#   m i s s a o 2 6  
 